 
 create database FIFAAPIDB
 use FIFAAPIDB

 drop table TeamsInfo
 create table teamsInfo
 (
  teamId   int ,
  teamName   varchar  (1000),
  teamCountry  varchar (1000) ,
  teamCoach varchar (1000),
  teamCaptain varchar (1000),
  teamLogo varchar (1000),
  teamJersey varchar (1000),
  constraint unk_teamName unique  (teamName),
  constraint pk_teamId primary key (teamId),
 )
  insert into teamsInfo values (101,'Real Madrid','Spain','Carlo Ancelotti','Iker Casillas',
                                'https://th.bing.com/th/id/OIP.XruTozkYrMQWp2Q3-lSV2AHaEK?w=324&h=182&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.DayzZQWVvJ4jumtD17bhHgHaHa?w=199&h=199&c=7&r=0&o=5&pid=1.7')                               
  insert into teamsInfo values (102,'Barcelona','Spain','Xavi Hernandez','Andr�s Iniesta',
                                'https://th.bing.com/th/id/OIP.Y27A3eP6MRvzlggD7ZUPMwHaEo?w=297&h=185&c=7&r=0&o=5&pid=1.7',
								'https://th.bing.com/th/id/OIP.VKr_hWQoDj5lhAlu8dGElgHaJu?w=148&h=194&c=7&r=0&o=5&pid=1.7')
 insert into teamsInfo values (103,'Ulsan Hyundai ',' south Korea','Hong Myung-bo' ,'Seyyed Jalal Hosseini',
                                'https://th.bing.com/th/id/OIP.UAdKk7-BvCadY05T2mNvHAHaJQ?w=151&h=189&c=7&r=0&o=5&pid=1.7',
								'https://th.bing.com/th/id/OIP.CWZo4eHvDidwWJjAbS1F6AHaHa?w=194&h=194&c=7&r=0&o=5&pid=1.7')
insert into teamsInfo values (104,'PSG',' France', 'Christophe Galtier','Jean Djorkaeff', 
                               'https://th.bing.com/th/id/OIP.v4KZ4ErRqmL6RqtjEGiyFwHaHv?w=172&h=180&c=7&r=0&o=5&pid=1.7',
							   'https://th.bing.com/th/id/OIF.OTKgOZndtNbWxn8RyoFcsg?w=324&h=161&c=7&r=0&o=5&pid=1.7')
insert into teamsInfo values (105,'Palmeiras ',' Brazil','Abel Ferreira','Gustavo Gomez ',
                                'https://th.bing.com/th/id/OIP.wc1gwNzM7SOcA75zB6xxywHaHa?w=180&h=180&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.Zz_d_vzJtindVtvu5JWKzAHaHa?w=196&h=196&c=7&r=0&o=5&pid=1.7')
                               
  insert into teamsInfo values (106,'Bayern Munich',' Germany', 'Hansi Flick', 'Manuel Neuer',
                                'https://th.bing.com/th/id/OIP.tjobPBBgvOmrm_NJKOlOfQHaHW?w=187&h=185&c=7&r=0&o=5&pid=1.7',
								'https://th.bing.com/th/id/OIP.hV5TRfjYj1JOS0W7juEs7AHaHa?w=196&h=196&c=7&r=0&o=5&pid=1.7')
                                
 insert into teamsInfo values (107,'Man Utd',' English', 'Erik ten Hag', 'Harry Maguire ',
                                'https://www.bing.com/th?id=OIP.hngKcj6wuBs4H38ssoskWwHaHg&w=248&h=251&c=8&rs=1&qlt=90&o=6&pid=3.1&rm=2',
								'https://th.bing.com/th/id/OIP.iuxR02ePvbuIQ3MD4pCJ-AHaJ4?w=156&h=208&c=7&r=0&o=5&pid=1.7')
                                
 insert into teamsInfo values (108,'Chelsea ',' England', 'Thomas Tuchel','Azpilicueta ',
                                'https://th.bing.com/th/id/OIP.Z5-bTIVzyHLkiPyVTWCYaAHaHa?w=205&h=205&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.zBEIMWzFvBFRe22GctpImgHaJs?w=159&h=208&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (109,'Mamelodi Sundowns FC ',' South Africa','Rhulani Mokwena','Andile Jali',
                                 'https://th.bing.com/th/id/OIP.jlbkPHZhlICk196O6WUZCwHaFL?w=257&h=180&c=7&r=0&o=5&pid=1.7',
                                 'https://th.bing.com/th/id/OIP.SAmTESY_JpCdYZG0tHVp_QHaIQ?w=174&h=194&c=7&r=0&o=5&pid=1.7')
                                 
  insert into teamsInfo values (110,'Arsenal',' England', 'Mikel Arteta', 'Martin Odegaard ',
                                'https://th.bing.com/th/id/OIP.qJJx5mLjGdhe661WHvLiaAHaFP?w=241&h=180&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.VnvbNTFrmC7gCC7knQHe2AHaHa?w=198&h=198&c=7&r=0&o=5&pid=1.7')
                               
 insert into teamsInfo values (111,' River Plate',' Argentina ', 'Marcelo Gallardo',' ', 
                                'https://wallpapercave.com/wp/wp3109916.png',
                                'https://www.soccerpro.com/wp-content/uploads/2018/01/bq9329_adidas_argentina_authentic_home_jsy_01.jpg')
                                
 
  insert into teamsInfo values (112,'Seattle Sounders FC ',' US','Brian Schmetzer','Cristian Roldan ',
                                'https://th.bing.com/th/id/OIP.iCP3UiO7BtQui0dhWYVeDwHaHa?w=175&h=180&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.pjOcraEKxLTwA0o8wWfoqwHaHa?w=199&h=199&c=7&r=0&o=5&pid=1.7')
                              
  insert into teamsInfo values (113,'Tigres UANL ',' Mexico ', 'Miguel Herrera','Lucas Lobos',
                                'https://th.bing.com/th/id/OIP.q7NVbQXxLfgK1Iain4AilwHaKu?w=132&h=192&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.O0yD9ZEHTIqxGqPSOchnMwHaIi?w=180&h=208&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (114,'Manchester city ',' England','Pep Guardiolas','Fernandinho',
                                'https://th.bing.com/th/id/OIP.HvJsh1P_0mnZyev0pD618QHaHa?w=174&h=180&c=7&r=0&o=5&pid=1.7',
                                'https://th.bing.com/th/id/OIP.NoWKjOqnAgaS6J0MlZzGxgHaHa?w=210&h=210&c=7&r=0&o=5&pid=1.7')
                              
  insert into teamsInfo values (115,' Atletico Madrid ',' Spain','Diego Simeone','Jos� Gim�nez',
                                'https://th.bing.com/th/id/OIP.O0WddVF6I7mHZy3mK6AijgHaJ3?w=138&h=184&c=7&r=0&o=5&pid=1.7',
								'https://th.bing.com/th/id/OIP.JmbS31CP4X5ngXR2lfGRvAHaIL?w=190&h=210&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (116,'Malmo FF ',' Sweden', 'Jon Dahl Tomasson','Sean Sabetkar',
                                'https://th.bing.com/th/id/OIP.9bFlqxq6_wjY9D6pA7NBOQAAAA?w=156&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.pD_vZe7464fXvznZjLEx0gHaJ7?w=147&h=197&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (117,'PSV Eindhoven',' Netherland','Ruud van Nistelrooy ','Marco van Ginkel',
                                'https://th.bing.com/th/id/OIP.hfrThZWo5oe8lbzzZThaqwAAAA?w=176&h=118&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.7sWxT--zyhBD1XkpiJLoawHaHa?w=213&h=213&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (118,'Nacional','Uruguay','Pablo Repetto','Montevideo F�tbo',
                                'https://th.bing.com/th/id/OIP.TBWKyaoI8Nh3rJOcsyxyCQHaJ4?w=135&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.UFQRUxOJra1YBkx_ftL5LgHaHa?w=203&h=203&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (119,'FC Porto ',' Portugal ','S�rgio Paulo ','Jo�o Pinto,',
                                'https://th.bing.com/th/id/OIP.t1t0SM5S9-v5temNWW4XXAHaEK?w=317&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.JfxKeslOPD0_fmf_7v0RgAHaHa?w=201&h=201&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (120,'Inter Milan ',' Italy','Simone Inzaghi','Samir Handanovic',
                                'https://th.bing.com/th/id/OIP.DVlZUAfl5JJUxiK1rHJd6AHaHa?w=197&h=197&c=7&r=0&o=5&pid=1.7',
						   	    'https://th.bing.com/th/id/OIP.-eOkJPonQlNEhN62z9eF2gHaHa?w=193&h=193&c=7&r=0&o=5&pid=1.7')
                               
  insert into teamsInfo values (121,'Young Boys ',' Switzerland','Matteo Vanetta','Fabian Lustenberger',
                                'https://th.bing.com/th/id/OIP.Ygni8aBLQQaJItgRVJ8UmwHaEo?w=300&h=187&c=7&r=0&o=5&pid=1.7',
							    'https://www.sportingplus.net/2027-thickbox_default/bsc-young-boys-away-jersey-2011-12-player-issue-for-race-puma.jpg')
                              
  insert into teamsInfo values (122,'Liverpool ',' England','J�rgen Klopp','Henderson',
                                'https://th.bing.com/th/id/OIP.46hDiM_1Kj7kpyHkTWTZDgHaNK?w=115&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.77hn3i76AgNqSXZjXmPM_gHaLD?pid=ImgDet&rs=1')
                               
  insert into teamsInfo values (123,'Kobenhavn ',' Denmark','Jess Thorup','William Kvist',
                               'https://th.bing.com/th/id/OIP.37dUQm4_A-ETznvb_UVl5AHaHa?w=175&h=180&c=7&r=0&o=5&pid=1.7',
							   'https://th.bing.com/th/id/OIP.wUnbIPc-MhoHFDFCdWq47QHaJB?w=146&h=180&c=7&r=0&o=5&pid=1.7')
                              
  insert into teamsInfo values (124,'Bayer Leverkusen ',' Germany','Gerardo Seoane','Moez Ben Cherifia',
                               'https://th.bing.com/th/id/OIP._oATYV8vpj6GW40qMPQ6-gHaHa?w=171&h=180&c=7&r=0&o=5&pid=1.7',
						       'https://th.bing.com/th/id/OIP.4HFU5sjYjs6KljdYXVENYAHaHa?w=201&h=200&c=7&r=0&o=5&pid=1.7')
                              
  insert into teamsInfo values (125,'Red Bull Salzburg ',' Australia','Red Bull Salzburg','Matthias Trattnig',
                               'https://th.bing.com/th/id/OIP.zs32FfPg__D_J-3F6r-bqwHaF-?w=244&h=197&c=7&r=0&o=5&pid=1.7',
						       'https://th.bing.com/th/id/OIP.deJW3zPq_bQfWRAYzOX5GwHaHU?w=199&h=196&c=7&r=0&o=5&pid=1.7')
                    
  insert into teamsInfo values (126,'Lech Poznan ',' Poland','John van den Brom','Mikael Ishak',
                                'https://th.bing.com/th/id/OIP.cBL_ULw-8DC228XaEC3PtAHaLW?w=115&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.jmzp9rdiRVHa-7Bdfp_ZVgHaHa?pid=ImgDet&rs=1')
                                
  insert into teamsInfo values (127,'Al Hilal',' Saudia Arabia','Ramon Diaz','Salman Al-Faraj',
                                'https://th.bing.com/th/id/OIP.g5Q0uBTUShFdl4Kw2qOwAwHaHa?w=178&h=180&c=7&r=0&o=5&pid=1.7',
							    'https://th.bing.com/th/id/OIP.bpL2Gw16ZkLBeBLax41EUQHaHa?w=208&h=208&c=7&r=0&o=5&pid=1.7')
                               
  insert into teamsInfo values (128,'Lyon ',' France','Michael Shedd','David Lyon',
                                'https://www.bing.com/th?id=OIP.UeNIVGpa64RmWSWrKSUh_AHaIw&w=229&h=271&c=8&rs=1&qlt=90&o=6&dpr=1.5&pid=3.1&rm=2',
								'https://th.bing.com/th/id/OIP.VYMcj3TZGkYa4WyyoGiJdgHaIZ?w=176&h=200&c=7&r=0&o=5&dpr=1.5&pid=1.7')
                                
  insert into teamsInfo values (129,'Club Brugge ',' Belgium','Carl Hoefkens','Blauw-Zwart',
                                'https://th.bing.com/th/id/OIP.XGvjXWBRkgWCM44NaEESzQHaIy?w=152&h=180&c=7&r=0&o=5&pid=1.7',
						    	'https://th.bing.com/th/id/OIP.s6DYkpyAZ4r7gMRG6-TFsQHaHa?w=200&h=200&c=7&r=0&o=5&pid=1.7')
                              
  insert into teamsInfo values (130,'Tottenham Hotspur ',' England','Antonio Conte','Lloris, Hugo',
                               'https://th.bing.com/th/id/OIP.wr57YErrKjtN1kja9KhxuQHaHa?w=162&h=180&c=7&r=0&o=5&pid=1.7',
							   'https://th.bing.com/th/id/OIP.OgLM4hoM0QV3nvTXg3oYEgHaHa?w=214&h=214&c=7&r=0&o=5&pid=1.7')
                             
  insert into teamsInfo values (131,'Al-Duhaik SC ',' Qatar','Hern�n Crespo','Lekhwiya ',
                                'https://th.bing.com/th/id/OIP.mSOmI-AGqaoYCXGKQFnSWQHaEo?w=259&h=180&c=7&r=0&o=5&pid=1.7',
								'https://th.bing.com/th/id/OIP.J5XIVRAyCIXAc-q0IB2wjQHaEK?w=286&h=180&c=7&r=0&o=5&pid=1.7')
                                
  insert into teamsInfo values (132,'Persepolis ','Iran','Yahya Golmohammadi','Hadi Norouzi',
                                'https://th.bing.com/th/id/OIP.0A7tChbnXdbm5ZhPeZZB8QHaEo?w=286&h=180&c=7&r=0&o=5&pid=1.7',
	    						'https://th.bing.com/th/id/OIP.knnuBJkiPcRr2dePfdHRdgAAAA?w=200&h=200&c=7&r=0&o=5&pid=1.7')
                        
                     
  select * from teamsInfo
  
   drop table PlayersInfo
	create table PlayersInfo
	(
		 playerId int ,
		 playerName varchar (255)  ,                          
		 playerPosition varchar (255),
		 playerTeamId  int,
		 PlayImageUrl varchar (100) ,
         constraint pk_playerId primary key (playerId),
	     constraint unk_playerName unique  (playerName),
	   	 constraint fk_playerTeamId  foreign key(playerTeamId) references teamsInfo
	)	
		 insert into PlayersInfo values (501,'Luka Modric ','Midfield', 101,'https://th.bing.com/th/id/OIP.MG_LnZdeWIEuu3HVZFDWcwHaId?w=137&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (502,'Toni Kroos','Midfield', 101,'https://th.bing.com/th/id/OIP.eZoYh-e1evf30azCOpkpdgHaKN?w=125&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (503,'Hazard, Eden ','Midfilder',101,'https://th.bing.com/th/id/OIP.bJXGlCYftdoUBxMYd-bUHAHaEo?pid=ImgDet&w=212&h=132&c=7.7')
		 insert into PlayersInfo values (504,'Alaba, David ','Froward', 101,'https://th.bing.com/th/id/OIP.McUM4n9FTLq5wBhnQb-ZzwHaLG?w=122&h=183&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (505,'Karim Benzema','Captain', 101,'https://th.bing.com/th/id/OIP.51t2JTI0hibKbTDLMrx87wHaE8?w=242&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (506,'Aur�lien Tchouam�ni',' midfielder', 101,'https://th.bing.com/th/id/OIP.FNCgeUFhFwOJyvoXBirtmAHaFj?w=241&h=181&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (507,'Dani Ceballos ','Midfilder', 101,'https://th.bing.com/th/id/OIP.cVassBjz1iyzaftvkgqjQQHaEK?w=329&h=185&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (508,'Ferland Mendy ','Defender', 101,'https://th.bing.com/th/id/OIP.EuybKrE_tK0FrZyCTM9yeQHaD8?w=298&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (509,'Luis Federico  ','GoalKeeper', 101,'https://th.bing.com/th/id/OIP.BrulFBmwz9g9kqHVc97W5AAAAA?w=129&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (510,'Antonio R�diger ','Defender ', 101,'https://th.bing.com/th/id/OIP.gN_5aLoTc6TMw8Qv8DSpagHaFy?w=225&h=180&c=7&r=0&o=5&pid=1.7')
		
		 insert into PlayersInfo values (511,'Pique, Gerard ','Defender', 102,'https://th.bing.com/th/id/OIP.QcbIuhEfvqNIzC6d56oHwgHaEy?w=266&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (512,'Pjanic, Miralem','Midfield',102,'https://th.bing.com/th/id/OIP.PZcvOgru42KcBxIG24M5-wHaHZ?w=188&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (513,'Andres Iniesta','Midfield',102,'https://th.bing.com/th/id/OIP.d6fwRTjPTdls0TB0gGiRywHaKh?w=140&h=199&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (514,'Braithwaite, Martin ','Froward', 102,'https://th.bing.com/th/id/OIP.YwA6eK7KZrk2rz21E7QudQHaFy?w=222&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (515,'Marc-Andre','GoalKeeper', 102,'https://th.bing.com/th/id/OIP.AZcRKumv8i3xkFswYRfmqwHaEK?w=319&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (516,'Umtiti,Samuel',' Defender', 102,'https://th.bing.com/th/id/OIP.KSh7GdRD6H1DYxPXnEjRHQHaGR?w=208&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (517,'Roberto,Sergi','Defender', 102,'https://th.bing.com/th/id/OIP.ti6fL7q8YvyvnEdjrV7O2gHaEK?w=294&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (518,'Depay,Memphis','Midfield', 102,'https://th.bing.com/th/id/OIP.D13sqQ2MTfv18_XOpAWSGQHaE7?w=238&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (519,'Dembele,Ousmane','Froward', 102,'https://th.bing.com/th/id/OIP.MoG3hhBqAUZtttIS90YRPAHaEK?w=295&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (520,'Torres,Ferran ','Froward ', 102,'https://th.bing.com/th/id/OIP.5uni-pM9fiIcIDEGlk91ngHaF7?w=217&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (521,'Young-Gwon, Kim ','Defender', 103,'https://th.bing.com/th/id/OIP.-EbiHAGp0rOsXWqapzSi-AHaFj?w=196&h=147&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (522,'Hyung-Min, Shin','Midfield',103,'https://th.bing.com/th/id/OIP.PZcvOgru42KcBxIG24M5-wHaHZ?w=188&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (523,'Kee-Hee, Kim','Defender',103,'https://th.bing.com/th/id/OIP.d6fwRTjPTdls0TB0gGiRywHaKh?w=140&h=199&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (524,'Leonardo ','Froward', 103,'https://th.bing.com/th/id/OIP.i2ie0lc3R0FGYdhO-FvbEQAAAA?w=140&h=185&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (525,'So-Huk, Jo','GoalKeeper',103,'https://th.bing.com/th/id/OIP.jLgc82YoMulyRqOxZ52CHgHaLG?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (526,'Lee,Chung-Yong',' Defender',103,'https://th.bing.com/th/id/OIP.JhS-GbgaViS2SPrjUYd16wHaFN?w=220&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (527,'Ho, Lee','Defender',103,'https://img.a.transfermarkt.technology/portrait/big/s_180804_6499_2011_1.jpg?lm=1')
		 insert into PlayersInfo values (528,'Qazaishvili, Vako','Midfield', 103,'https://th.bing.com/th/id/OIP.4i3iB7GDs_VjvEn5REwbawHaLG?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (529,'Won-Sang, Eom','Froward',103,'https://th.bing.com/th/id/OIP.JXexv7Wg1AhtjGeS6TfywQHaJn?w=196&h=254&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (530,'Chu-Young, Park ','Froward ', 103,'https://th.bing.com/th/id/OIP.Tqkp7pBHFe3F2hpwsP6YFQHaFj?w=244&h=183&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (531,'Wijnaldum,Georginio','Midfield', 104,'https://th.bing.com/th/id/OIP.-5pFtn9l8XHtv4uZTWRFSgHaEK?w=312&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (532,'Rafinha','Midfield',104,'https://th.bing.com/th/id/OIP.cCRMXznEbdO9mhheSk_NJgHaKG?w=132&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (533,'Herrera,Ander','Midfield',104,'https://th.bing.com/th/id/OIP.NgzkpBMEnbPXuF5bnsWgCwHaFj?w=237&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (534,'Neymar ','Froward', 104,'https://th.bing.com/th/id/OIP.u26skfoH9Uo1EZb-oEcacgHaE8?w=236&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (535,'Navas,Keylor','GoalKeeper',104,'https://th.bing.com/th/id/OIP.2hEMuivc4tJjidWIHFbaugHaF4?w=218&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (536,'Bernat,Juan',' Defender',104,'https://th.bing.com/th/id/OIP.PcuPZx0HQ1Esgci6sV_kcwHaE8?w=269&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (537,'Pereira,Danilo','Midfield',103,'https://th.bing.com/th/id/OIP.TrePNhnBFFsFy4kAXxTlngHaEK?w=319&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (538,'Gueye, Idrissa','Midfield', 104,'https://th.bing.com/th/id/OIP.m5G8HqEcwauyZqh9kV4DtAHaEK?w=301&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (539,'Verratti, Marco','Midfield',104,'https://th.bing.com/th/id/OIP.Xe_XNNg8-njmMOeHLB9thAHaGU?w=183&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (540,'Chu-Young, Park ','Froward ', 104,'https://th.bing.com/th/id/OIP.Tqkp7pBHFe3F2hpwsP6YFQHaFj?w=244&h=183&c=7&r=0&o=5&pid=1.7')
		
		 insert into PlayersInfo values (541,'Kuscevic, Benjamin','Midfield', 105,'https://th.bing.com/th/id/OIP.KSeywweVWELPm_Su2Wo7KgAAAA?w=155&h=183&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (542,'Jorge','Defender',105,'https://th.bing.com/th/id/OIP.2Rm-nMDQPgCjGacu3vhdsgHaL0?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (543,'Wesley','Midfield',105,'https://th.bing.com/th/id/OIP.oLUaXSkGZwzUmRSNitV2kwHaIl?w=154&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (544,'Mayke ','Defender', 105,'https://th.bing.com/th/id/OIP.NtWLD3gH3zmcUZKUbF2B6QAAAA?w=136&h=150&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (545,'Mateus','GoalKeeper',105,'https://th.bing.com/th/id/OIP.UjITuHWwqyoI3vy0xg0XWQHaHa?w=168&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (546,'Breno',' Froward',105,'https://th.bing.com/th/id/OIP.Rui4UFnv9LNYy0ulv0JQggHaDt?w=319&h=175&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (547,'Gustavo Gomez','Midfield',105,'https://th.bing.com/th/id/OIP.7F3_VkcANS-6SgClvM8VrAHaE7?w=251&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (548,'Atuesta, Eduard','Midfield', 105,'https://th.bing.com/th/id/OIP.k3AtU-SsTRKsx8bNSy8k3wHaEc?w=263&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (549,'Cerqueira, Murilo','Defender',105,'https://th.bing.com/th/id/OIP.sJZ1rCk66MlkVS41OK6dgwAAAA?w=134&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (550,'Deyverson ','Froward ', 105,'https://th.bing.com/th/id/OIP.HmkC09wGsNnEf0qEo2QjqAHaIC?w=158&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (551,'Sabitzer, Marcel','Midfield', 106,'https://th.bing.com/th/id/OIP.3bVYsTPi2hJZ73Yp09u9QgHaE8?w=262&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (552,'Sarr, Bouna','Defender',106,'https://th.bing.com/th/id/OIP.qoXUi9IVmjypnUJ076EW2AHaES?w=295&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (553,'Goretzka, Leon','Midfield',106,'https://th.bing.com/th/id/OIP.yYvXG7W-XdibltMfmWqP4QHaEK?w=319&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (554,'Pavard, Benjamin ','Defender', 106,'https://th.bing.com/th/id/OIP.eBcAzSa2UvsksALF5rmNJAHaEk?w=278&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (555,'Neuer, Manuel','GoalKeeper',106,'https://th.bing.com/th/id/OIP.l7Z8vEhMfD_gOFKOFb94UQHaEK?w=308&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (556,'Muller, Thomas',' Froward',106,'https://th.bing.com/th/id/OIP.hPhJ6L_AHEZ2E73xXutFTgHaE8?w=242&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (557,'Gnabry, Serge','Froward',106,'https://th.bing.com/th/id/OIP.51yvvNvDXCC8cU1Uq-NhIgHaFP?w=228&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (558,'Kimmich, Joshua','Midfield', 106,'https://th.bing.com/th/id/OIP.eDM2MQiQKl2sqdgavaMMbgHaEK?w=316&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (559,'Hernandez, Lucas','Defender',106,'https://th.bing.com/th/id/OIP.JXygXaQiO32vQqvUqatVnAHaEK?w=284&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (560,'Choupo-Moting, Eric Maxim ','Froward ', 106,'https://th.bing.com/th/id/OIP.MJmGNVL63BvCH6UEeYQt8QHaE3?w=268&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (561,'Ronaldo, Cristiano','Froward', 107,'https://th.bing.com/th/id/OIP.d-S-PeYqXF_EWdnNgzNiEwHaIe?w=151&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (562,'Maguire, Harry','Defender',107,'https://th.bing.com/th/id/OIP.ok4lQyprRIIrmtxY4eEo_QHaE_?w=244&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (563,'Fernandes, Bruno','Midfield',107,'https://th.bing.com/th?id=OIF.SQLAVQbZX9S%2bxGqPjmBPmQ&w=240&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (564,'Jones, Phil ','Defender', 107,'https://th.bing.com/th/id/OIF.lJpsORpqKemDr65CsNJj1A?w=291&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (665,'Heaton, Tom','GoalKeeper',107,'https://th.bing.com/th/id/OIP.zxF_3UUGWSe0IYPYH0Gy_gHaKM?w=130&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (566,'Martial, Anthony',' Froward',107,'https://th.bing.com/th/id/OIP.oWl5-YC4yPJgxMSbvP1rXwHaE7?w=274&h=183&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (567,'Rashford, Marcus','Froward',107,'https://th.bing.com/th/id/OIP.93mckLhQkP8n_-66Li3VLAHaFj?w=244&h=183&c=7&r=0&o=5&pid=1.77')
		 insert into PlayersInfo values (568,'Fred','Midfield', 107,'https://th.bing.com/th/id/OIP.7y67oNX3KK7kRdHUnc8TrwEsCd?w=292&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (569,'Lindelof, Victor','Defender',107,'https://th.bing.com/th/id/OIP.mArJGOseq0L-Rc1tiZozaAHaE8?w=258&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (570,'Pereira, Andreas ','Midfield ', 107,'https://th.bing.com/th/id/OIP.5oOP3HGJw4KnlKW3mpvoFgHaE8?w=264&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (571,'Pulisic, Christian','Froward', 108,'https://th.bing.com/th/id/OIP.ZzW7Rsz9kMFCIhdGuP_dRQHaHa?w=166&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (572,'Kante, N`Golo','Midfield',108,'https://th.bing.com/th/id/OIP.fBuvhZqRgJTaF2fqmcuACwHaE8?w=246&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (573,'Chalobah, Trevoh','Defender',108,'https://th.bing.com/th/id/OIP.kqy4K9OGMk-wtsGjisO71wHaEJ?w=300&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (574,'Rudiger, Antonio ','Defender', 108,'https://th.bing.com/th/id/OIP.oSd4woMqwfcy-i12oAFpQAHaEK?w=289&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (675,'Bettinelli, Marcus','GoalKeeper',108,'https://th.bing.com/th/id/OIP.sh4oDY5EYsFBWEl8BxgpXAHaFj?w=219&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (576,'Kenedy, Robert',' Froward',108,'https://th.bing.com/th/id/OIP.TdxsMjyMbsWGMXVLEjQx3QHaE7?w=264&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (577,'Hudson-Odoi, Callum','Froward',108,'https://th.bing.com/th/id/OIP.YEDoCQq9dOMb5JXA07AuFwHaDt?w=350&h=175&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (578,'Niguez, Saul','Midfield', 108,'https://th.bing.com/th/id/OIP.dcSeLFEw1CAYrbsfHGxGtgHaFj?w=215&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (579,'Sarr, Malang','Defender',108,'https://th.bing.com/th/id/OIP.IhI1snAAkkNUoPSjDGsUNAHaFk?w=219&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (580,'Barkley, Ross ','Midfield ', 108,'https://th.bing.com/th/id/OIP.QPQ1ZQUZI9XyzPHcZTuiqwHaHu?w=169&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (581,'Erasmus, Kermit','Froward', 109,'https://th.bing.com/th/id/OIP.XE2tbDPjxT0Oy4DP0GSwYQHaFj?w=245&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (582,'Jali, Andile','Midfield',109,'https://th.bing.com/th/id/OIP.4t1RHPxhxFFlUOWEeuIGzQHaHa?w=204&h=204&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (583,'Nascimento, Ricardo','Defender',109,'https://th.bing.com/th/id/OIP.HVOdaO1kuP-iEnT9jkd36AAAAA?w=162&h=201&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (584,'Soumahoro, Bangaly ','Defender', 109,'https://th.bing.com/th/id/OIP.__1adIjqvEfODYi6nd0rGQHaEK?w=293&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (685,'Mweene, Kennedy','GoalKeeper',109,'https://th.bing.com/th/id/OIP.gZkUkAXcxNJujKrPMG0rBwHaFB?w=269&h=182&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (586,'Safranko, Pavol',' Froward',109,'https://th.bing.com/th/id/OIP.0S4l4VJ1DC-E5cBfEujntgHaLo?w=121&h=190&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (587,'Vilakazi, Sibusiso','Froward',109,'https://th.bing.com/th/id/OIP.-YoB_pxbeP8gnxLov5xKDAHaFL?w=264&h=185&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (588,'Kekana, Hlompho','Midfield', 109,'https://th.bing.com/th/id/OIP.gde8yEP705w2KrUjls5IVwHaFC?w=274&h=186&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (589,'Coetzee, Rivaldo','Defender',109,'https://th.bing.com/th/id/OIP._ceQoVCZkqe4_9e2OVKBpwHaLH?w=131&h=196&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (590,'Zwane, Themba ','Midfield ', 109,'https://th.bing.com/th/id/OIP.J1Nena1HwA9VYkp7JPKjZgHaHa?w=205&h=205&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (591,'Pepe, Nicolas','Froward', 110,'https://th.bing.com/th/id/OIP._Pb8Whtm0acBYLrGsOOWCgHaHa?w=165&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (592,'Xhaka, Granit','Midfield',110,'https://th.bing.com/th/id/OIP.3C0S606JTKgXImtoVKZpagHaEt?w=265&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (593,'Soares, Cedric','Defender',110,'https://th.bing.com/th/id/OIP.ICL-ZyggZew6CIktjqwyXAHaHa?w=171&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (594,'Bellerin, Hector ','Defender', 110,'https://th.bing.com/th/id/OIP.a0e3sXRxZKEqOQATyp9NtwHaJ5?w=130&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (695,'Leno, Bernd','GoalKeeper',110,'https://th.bing.com/th/id/OIP.M7wNPVOuw9-l3iYIHl76dQHaFj?w=236&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (596,'Jesus, Gabriel',' Froward',110,'https://th.bing.com/th/id/OIP.pSlQ_L5piDW06QJ76H044QHaE8?w=260&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (597,'Nelson, Reiss','Froward',110,'https://th.bing.com/th/id/OIP.OzBZ6nuLtt21NGaIBo0B2wHaEK?w=288&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (598,'Elneny, Mohamed','Midfield', 110,'https://th.bing.com/th/id/OIP.K0WsKZSCOA-r_cUh2kbg_AHaFj?w=217&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (599,'Mari, Pablo','Defender',110,'https://th.bing.com/th/id/OIP.46i51XjArRUb6OggDSNU3gHaJd?w=147&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (600,'Partey, Thomas ','Midfield ', 110,'https://th.bing.com/th/id/OIP._5bF-Ht89o66-gQxehFICAHaE7?w=262&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (601,'Suarez, Matias','Froward', 111,'https://th.bing.com/th/id/OIP.9-kC4-A4dsBVzJLgLqBhuQHaE5?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (602,'Perez, Enzo','Midfield',111,'https://playerswiki.com/uploads/biography/2018/05/25/enzo-perez.jpg')
		 insert into PlayersInfo values (603,'Pinola, Javier','Defender',111,'https://e1.365dm.com/12/01/2048x1152/Javier-Pinola_2701484.jpg')
		 insert into PlayersInfo values (604,'Maidana, Jonatan ','Defender', 111,'https://th.bing.com/th/id/R.fec4e3e1d3ff6eea7b0cf94d93787596?rik=qkW7FnqUfwW38A&pid=ImgRaw&r=0')
		 insert into PlayersInfo values (605,'Armani, Franco','GoalKeeper',111,'https://smartbiography.com/wp-content/uploads/2020/10/Goalkeeper-Franco-Armani-of-River-Plate.jpg')
		 insert into PlayersInfo values (606,'Beltran, Lucas',' Froward',111,'https://th.bing.com/th/id/OIP.5YbBSD_X4vfQIGzQ1Xi5UQHaEJ?w=299&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (607,'Romero, Braian','Froward',111,'https://th.bing.com/th/id/OIP.AaAIuPLDKkYGMJOpou06UQHaEK?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (608,'Quintero, Juan','Midfield', 111,'https://th.bing.com/th/id/OIP.RcF9AZAOWPS-TqFnqc_pBAHaHa?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (609,'Casco, Milton','Defender',111,'https://th.bing.com/th/id/OIP.I6MlERuX9RM3oZTPrc9Q4AHaJK?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (610,'Zuculini, Bruno ','Midfield ', 111,'https://cdn.staticneo.com/w/pes/thumb/1/11/Zuculini_2019.jpg/410px-Zuculini_2019.jpg')
		
		 insert into PlayersInfo values (611,'Montero, Fredy','Froward', 112,'https://th.bing.com/th/id/OIP.pSJ5B1J61l5tXBNVP5_p0AHaEK?w=300&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (612,'Lodeiro, Nicolas','Midfield',112,'https://th.bing.com/th/id/OIP.DqZQkUL7rgrPmJgDO-zMLAAAAA?w=119&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (613,'Medranda, Jimmy','Defender',112,'https://e1.365dm.com/12/01/2048x1152/Javier-Pinola_2701484.jpg')
		 insert into PlayersInfo values (614,'Tolo, Nouhou ','Defender', 112,'https://th.bing.com/th/id/OIP.SMhBZkvRCRMGQmrcEYV9OgHaFY?w=263&h=191&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (615,'Frei, Stefan','GoalKeeper',112,'https://i.ytimg.com/vi/J3yiflzYRkE/maxresdefault.jpg')
		 insert into PlayersInfo values (616,'Morris, Jordan',' Froward',112,'https://th.bing.com/th/id/OIP.YbpiCI9hNV0i9DvNo_k_VwHaJl?w=133&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (617,'Bruin, Will','Froward',112,'https://th.bing.com/th/id/OIP.XWfh9XjC1UGjFGXdIZZiiQHaFY?w=237&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (618,'Rowe, Kelyn','Midfield', 112,'https://th.bing.com/th/id/OIP.DApYCXnhoCFZax7zcVxZtwHaKu?w=128&h=185&c=7&r=0&o=5&pid=1.71')
		 insert into PlayersInfo values (619,'Arreaga, Xavier','Defender',112,'https://th.bing.com/th/id/OIP.d-TE69bG_eQziRygWk_zqgHaFI?w=247&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (620,'Rusnak, Albert ','Midfield ', 112,'https://th.bing.com/th/id/OIP.1IXGZC3EJUDIiBqTJLCXCQHaFj?w=226&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (611,'Montero, Fredy','Froward', 112,'https://th.bing.com/th/id/OIP.pSJ5B1J61l5tXBNVP5_p0AHaEK?w=300&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (612,'Lodeiro, Nicolas','Midfield',112,'https://th.bing.com/th/id/OIP.DqZQkUL7rgrPmJgDO-zMLAAAAA?w=119&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (613,'Medranda, Jimmy','Defender',112,'https://e1.365dm.com/12/01/2048x1152/Javier-Pinola_2701484.jpg')
		 insert into PlayersInfo values (614,'Tolo, Nouhou ','Defender', 112,'https://th.bing.com/th/id/OIP.SMhBZkvRCRMGQmrcEYV9OgHaFY?w=263&h=191&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (615,'Frei, Stefan','GoalKeeper',112,'https://i.ytimg.com/vi/J3yiflzYRkE/maxresdefault.jpg')
		 insert into PlayersInfo values (616,'Morris, Jordan',' Froward',112,'https://th.bing.com/th/id/OIP.YbpiCI9hNV0i9DvNo_k_VwHaJl?w=133&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (617,'Bruin, Will','Froward',112,'https://th.bing.com/th/id/OIP.XWfh9XjC1UGjFGXdIZZiiQHaFY?w=237&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (618,'Rowe, Kelyn','Midfield', 112,'https://th.bing.com/th/id/OIP.DApYCXnhoCFZax7zcVxZtwHaKu?w=128&h=185&c=7&r=0&o=5&pid=1.71')
		 insert into PlayersInfo values (619,'Arreaga, Xavier','Defender',112,'https://th.bing.com/th/id/OIP.d-TE69bG_eQziRygWk_zqgHaFI?w=247&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (620,'Rusnak, Albert ','Midfield ', 112,'https://th.bing.com/th/id/OIP.1IXGZC3EJUDIiBqTJLCXCQHaFj?w=226&h=180&c=7&r=0&o=5&pid=1.7')
		
		 insert into PlayersInfo values (621,'Gignac,Andre Pierre','Froward', 113,'https://th.bing.com/th/id/OIP.ncOp8EjfVaPdedLxGtYiowHaEk?w=283&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (622,'Carioca,Rafael','Midfield',113,'https://th.bing.com/th/id/OIP.iCMFSsfa_VeAi7y30LRvwAHaHa?w=159&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (623,'Reyes, Diego','Defender',113,'https://th.bing.com/th/id/OIP.nzfVPECc0Vi-qejbGcfvTwHaI_?w=136&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (624,'Angulo, Jesus ','Defender', 113,'https://th.bing.com/th/id/OIP.RpdOoPWyj6JTsOJmwdTTbgHaEK?w=329&h=185&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (625,'Guzman, Nahuel','GoalKeeper',113,'https://th.bing.com/th/id/OIP.SrZUAs90Crm-4zV4vAq0AgAAAA?w=138&h=195&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (626,'Lopez, Nicolas',' Froward',113,'https://th.bing.com/th/id/OIP.IjjktlSipqI-HXFuwolGyQHaFI?w=248&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (627,'Thauvin, Florian','Froward',113,'https://th.bing.com/th/id/OIP.95F1PG2sguD_velxNfkb1AHaJ4?w=121&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (628,'Pizarro,Guido','Midfield', 113,'https://th.bing.com/th/id/OIP.ydeFhw9Wa4Lm6fskYBV_9QAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (629,'Ayala, Hugo','Defender',113,'https://th.bing.com/th/id/OIP.03cTtwbUH9ImVosVVQ0rvQHaEK?w=293&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (630,'Aquino, Javier ','Midfield ', 113,'https://th.bing.com/th/id/OIP.352rZxoP8zYluXBp266G9AHaFj?w=241&h=181&c=7&r=0&o=5&pid=1.7')
		
		 insert into PlayersInfo values (631,'Sterling, Raheem','Froward', 114,'https://th.bing.com/th/id/OIP.LKhz0yP9L4VRC4T__VyRbAHaEf?w=274&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (632,'Gundogan, Ilkay','Midfield',114,'https://th.bing.com/th/id/OIP.nVcvUqKUMyh82tdf9nc_gQHaHa?w=157&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (633,'Walker, Kyle','Defender',114,'https://th.bing.com/th/id/OIP.izJgN-vvJytpQ6M3p_WpOAAAAA?w=133&h=193&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (634,'Cancelo, Joao ','Defender', 114,'https://th.bing.com/th/id/OIP.oOPumAxkHjVbQJgWFLRBhgHaEK?w=316&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (635,'Carson, Scott','GoalKeeper',114,'https://th.bing.com/th/id/OIP.NjFujQ4iQsu-aPXln3CIvQHaE7?w=260&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (636,'Mahrez, Riyad',' Froward',114,'https://th.bing.com/th/id/OIP.CoP_EkR-n8gDieUQs9s05wHaFy?w=227&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (637,'Grealish, Jack','Froward',114,'https://th.bing.com/th/id/OIP.Fpr1hdsFmE5ZhdGQ1Dq7_AHaE8?w=247&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (638,'DenBruyne, Kevin','Midfield', 114,'https://th.bing.com/th/id/OIP.bDsIpxm8HnETFBumnylDYQFZC0?w=324&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (639,'Mendy,Benjamin','Defender',114,'https://th.bing.com/th/id/OIP.mKLCBI7fSxgTLEItqe33DAHaEK?w=310&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (640,'Silva, Bernardo ','Midfield ',114,'https://th.bing.com/th/id/OIP.GQYziRsFZ5dbnkGuFDOaIgEsCo?w=301&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (641,'Griezmann, Antoine','Froward', 115,'https://th.bing.com/th/id/OIP.NTBXvOzHUpTbKIWdmKyQZQHaEX?w=289&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (642,'Wass,Daniel','Midfield',115,'https://th.bing.com/th/id/OIP.xgIdLEq2_pi3k0Ysuth74QAAAA?w=134&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (643,'Savic,Stefan','Defender',115,'https://th.bing.com/th/id/OIP.J0IbvSus_oNDKM6i0AloXQHaFj?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (644,'Gimenez,Jose ','Defender', 115,'https://th.bing.com/th/id/OIP.S4yyEq-zLEXmUlaJ-AOqFAAAAA?w=139&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (645,'Oblak, Jan','GoalKeeper',115,'https://th.bing.com/th/id/OIP.dvCmHYpj8Fpr-6UamcdvvQHaE8?w=271&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (646,'Morata, Alvaro',' Froward',115,'https://th.bing.com/th/id/OIP.Qeh_TgAs1u6mfic_QIwThQHaD4?w=337&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (647,'Lemar, Thomas','Froward',115,'https://th.bing.com/th/id/OIP.8BPUX9ch2_cUF410kx_UFQHaHS?w=169&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (648,'Koke','Midfield', 115,'https://th.bing.com/th/id/OIP.bgBYggKm6U_MRW-Wgs8N2gHaGL?w=192&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (649,'Arias, Santiago','Defender',115,'https://th.bing.com/th/id/OIP.p18-3J4m5aCK8wE3GKma1wHaL9?w=121&h=196&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (650,'Kondogbia, Geoffrey ','Midfield ',115,'https://th.bing.com/th/id/OIP.YxzCWDTFCffaM_4XX6gMIgAAAA?w=180&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (651,'Toivonen,Ola','Froward', 116,'https://th.bing.com/th/id/OIP.QVkPpiGJGLDtIdudgj72bAHaFj?w=238&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (652,'Rieks, Soren','Midfield',116,'https://th.bing.com/th/id/OIP.8JFqq1h6ukL45P5iM2bxZAAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (653,'Moisander,Niklas','Defender',116,'https://th.bing.com/th/id/OIP.tig5S_KV79kneChsZZCuqgHaFj?w=209&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (654,'Nielsen, Lasse ','Defender', 116,'https://th.bing.com/th/id/OIP.XisvGTACfEiWmrcYgQVJGQAAAA?w=133&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (655,'Dahlin,Johan','GoalKeeper',116,'https://th.bing.com/th/id/OIP.OJLUDyuiwMSWlIHsKy8l3QHaFj?w=226&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (656,'Berget,Jo Inge',' Froward',116,'https://th.bing.com/th/id/OIP.wy_uWBPYKl-p4RhRwkDHRAHaFj?w=240&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (657,'Thelin, Isaac','Froward',116,'https://th.bing.com/th/id/OIP.fD4NTN1ey07ho3LrXzLPaQAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (658,'Christiansen, Anders','Midfield', 116,'https://th.bing.com/th/id/OIP.0pTo9fBsxlac832v3yAK6gHaEK?w=315&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (659,'Olsson,Martin','Defender',116,'https://th.bing.com/th/id/OIP.o05vcKK8smuWoQYrUJDN5gAAAA?w=155&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (660,'Lewicki, Oscar ','Midfield ',116,'https://th.bing.com/th/id/OIP.j_mWBKufA_x-titj9pOArgAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (661,'Vinicius, Carlos','Froward', 117,'https://th.bing.com/th/id/OIP.OGmWv9xxE3lUPImV2wIl5wHaEJ?w=312&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (662,'Doan, Ritsu','Midfield',117,'https://th.bing.com/th/id/OIP.YzhqkG-nKrpK-L9x8c-IJAHaHq?w=189&h=196&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (663,'Mwene, Philipp','Defender',117,'https://th.bing.com/th/id/OIP.cYeELZHgtwPEAEGka-rp2gAAAA?w=162&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (664,'Obispo, Armando ','Defender', 117,'https://th.bing.com/th/id/OIP.xJXsdq6iwt4OJ81ltIVx5QAAAA?w=168&h=349&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (665,'Drommel, Joel','GoalKeeper',117,'https://th.bing.com/th/id/OIP.XCpNNHZoJ7yTxYanh3GXjAAAAA?w=115&h=186&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (666,'Bruma',' Froward',117,'https://th.bing.com/th/id/OIP.Jz7KUqd2L58lEr6FUz4bFwHaFY?w=242&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (667,'Gakpo, Cody','Froward',117,'https://th.bing.com/th/id/OIP.3VcJfP2dqpa-jhkhB2DtqwAAAA?w=169&h=212&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (668,'Gutierrez, Erick','Midfield', 117,'https://th.bing.com/th/id/OIP.hq1xFaOIeUYR7Ka7ckG84AHaId?w=138&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (669,'Ramalho, Andre','Defender',117,'https://th.bing.com/th/id/OIP.2XfKRQTmhL1lMJzTt22txgAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (670,'Sangare, Ibrahim ','Midfield ',117,'https://th.bing.com/th/id/OIP.opzEdHN7MZKj8IhbPm0zBAHaLS?w=116&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (671,'Gigliotti, Emanuel','Froward', 118,'https://th.bing.com/th/id/OIP.I9emaPLYuZZ0b5kku95SkwHaKO?w=121&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (672,'Carballo, Felipe','Midfield',118,'https://th.bing.com/th/id/OIP.MMP8r6EMRiFRUSRh7XMpYgHaEo?w=282&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (673,'Risso, Mario','Defender',118,'https://th.bing.com/th/id/OIP.oXAorTLQKcQQZrZhatme_wHaE9?w=261&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (674,'Laborda, Mathias ','Defender', 118,'https://th.bing.com/th/id/OIP.iba9Wlyqaow8lJJ1jjM2WwHaFF?w=266&h=183&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (675,'Rochet, Sergio','GoalKeeper',118,'https://th.bing.com/th/id/OIP.4TvZymGzy9HoQR03IgF33QAAAA?w=140&h=186&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (676,'Landsten, Karl',' Froward',118,'https://th.bing.com/th/id/OIP.P3eSrwTbJ_nIWcgtvFWN4AHaGE?w=203&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (677,'Ramirez, Ignacio','Froward',118,'https://th.bing.com/th/id/OIP.0l89a_2pBxvLUrb-yJ9qowHaHa?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (678,'Otormin, Leandro','Midfield', 118,'https://th.bing.com/th/id/OIP.d95CSdQ__vIXfBbRD5lcOwExDM?w=284&h=190&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (679,'Rodriguez,Jose Luis','Defender',118,'https://th.bing.com/th/id/OIP.-AiVklMpHvLP7IyKQgWm8gHaEK?w=324&h=182&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (680,'Almeida, Christian ','Midfield ',118,'https://th.bing.com/th/id/OIP.luyj4NqtwqX427OiSiZuwAHaE9?w=261&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (681,'Nakajima, Shoya','Froward', 119,'https://th.bing.com/th/id/OIP.E7gC04vgT_scN7WtCmWH8QHaOW?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (682,'Grujic, Marko','Midfield',119,'https://th.bing.com/th/id/OIP.JyPby5iPiSXoHJkksdpFywHaHa?w=189&h=189&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (683,'Wendell','Defender',119,'https://th.bing.com/th/id/OIP.4afhuvHtgmek9Ts--CMT3wHaFT?w=229&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (64,'Pepe','Defender', 119,'https://th.bing.com/th/id/OIP.y_sqLz8BVZc3-_QVKWeJlgHaD4?w=322&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (685,'Costa, Diogo','GoalKeeper',119,'https://th.bing.com/th/id/OIP.vKFQDT9j4PKSaiRwFnau_QHaFj?w=237&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (686,'Andrade,Fernando',' Froward',119,'https://th.bing.com/th/id/OIP.9KogKDgiMoFd4RNYXKwHwwHaE8?w=253&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (687,'Martinez, Toni','Froward',119,'https://th.bing.com/th/id/OIP.-ksZzhrQtCMxMMZWSXeTXwAAAA?w=122&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (688,'Otavio','Midfield', 119,'https://th.bing.com/th/id/OIP.Wa-xLk0bwLTNvPe5JtoRnAHaEl?w=287&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (689,'Marcano, Ivan','Defender',119,'https://th.bing.com/th/id/OIP.YqFbbhc5nyYRpjcdjzpqkgAAAA?w=166&h=202&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (690,'Oliveira,Sergio','Midfield ',119,'https://th.bing.com/th/id/OIP.ZbFqXFRRUPzWJF7tVNE1UwHaFj?w=243&h=182&c=7&r=0&o=5&pid=1.7')
		

		 insert into PlayersInfo values (691,'Dzeko, Edin','Froward', 120,'https://th.bing.com/th/id/OIP.OIc8XAMvGCqaIECPl_jl1gHaFX?w=243&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (692,'Vidal, Arturo','Midfield',120,'https://th.bing.com/th/id/OIP.4UGUqNpKJbFjlgPu0xbBTAAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (693,'Darmian, Matteo','Defender',120,'https://th.bing.com/th/id/OIP.kN4pdqXyUivGk77G5NPVaAHaGz?w=174&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (694,'De Vrij, Stefan','Defender', 120,'https://th.bing.com/th/id/OIP.3yKpvXZ0HzeRnreHFOpXYwHaEl?w=298&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (695,'Handanovic, Samir','GoalKeeper',120,'https://th.bing.com/th/id/OIP.PaKcdzWYTwbCbcVKSy6bKgAAAA?w=138&h=183&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (696,'Sanchez, Alexis',' Froward',120,'https://th.bing.com/th/id/OIP.2wUPsv4RJQPBbACYTYVDDwHaFj?w=226&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (697,'Lukaku, Romelu','Froward',120,'https://th.bing.com/th/id/OIP.YPAIGrrjSFDU-ULwT8gjuwHaI0?w=148&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (698,'Mkhitaryan, Henrikh','Midfield', 120,'https://th.bing.com/th/id/OIP.ncuauRijr5uM6qQulJ3wTQHaGE?w=190&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (699,'D`Ambrosio, Danilo','Defender',120,'https://th.bing.com/th/id/OIP.R8UJb7aaPiuadLKNU2uT_QHaKn?w=130&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (700,'Brozovic, Marcelo','Midfield ',120,'https://th.bing.com/th/id/OIP.m4b9sCrQK1-xLrLDA_ts-wHaFr?w=234&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (701,'Kanga, Wilfried','Froward', 121,'https://th.bing.com/th/id/OIP.RV06tWy3LqHSQ3a8vrMFFAHaE8?w=261&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (702,'Fassnacht, Christian','Midfield',121,'https://th.bing.com/th/id/OIP.4UGUqNpKJbFjlgPu0xbBTAAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (703,'Benito, Loris','Defender',121,'https://th.bing.com/th/id/OIP.qhnP32Rd_EBkue4a9ZWOtwHaEK?w=328&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (704,'Lustenberger, Fabian','Defender', 121,'https://th.bing.com/th/id/OIP.TRprlzPmDRjSRf9NE8ujRgHaFj?w=268&h=201&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (705,'Racioppi, Anthony','GoalKeeper',121,'https://th.bing.com/th/id/OIP.xwrRV-XYkSLnqeubtWr5GQHaHa?w=200&h=200&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (706,'Nsame, Jean-Pierre',' Froward',121,'https://th.bing.com/th/id/OIP.LhTGc7aKq45VVkChBf1OrAHaE8?w=267&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (707,'Itten, Cedric','Froward',121,'https://th.bing.com/th/id/OIP.0hjZwViW2SHuvzl_20KRVwHaEd?w=298&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (708,'Sierro, Vincent','Midfield', 121,'https://th.bing.com/th/id/OIP.xMr_9CSZlpiBoDfi9sv_EwAAAA?w=127&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (709,'Lefort, Jordan','Defender',121,'https://th.bing.com/th/id/OIP.sHr2OYmyMgvPL6YB2zL4EgHaLG?w=129&h=194&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (710,'Moumi, Nicolas','Midfield ',121,'https://th.bing.com/th/id/OIP.VfDsiPLJfGyTSRVo9CuxfgAAAA?w=162&h=180&c=7&r=0&o=5&pid=1.7')


		 insert into PlayersInfo values (711,'Firmino, Roberto','Froward', 122,'https://th.bing.com/th/id/OIP.RV06tWy3LqHSQ3a8vrMFFAHaE8?w=261&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (712,'Milner, James','Midfield',122,'https://th.bing.com/th/id/OIP.ByTCuBdua6l_DFx_TH12AQHaEo?w=295&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (713,'Matip, Joel','Defender',122,'https://th.bing.com/th/id/OIP.zHMOyv7r8_-Y8KxPqNnZnwHaFj?w=238&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (714,'van Dijk, Virgil','Defender', 122,'https://th.bing.com/th/id/OIP.ym2UBqAVhCy5oaGlHVXk-AHaE4?w=269&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (715,'Adrian','GoalKeeper',122,'https://th.bing.com/th/id/OIP.RxnUx3h5c9ZrUtqDvn1isQAAAA?w=192&h=192&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (716,'Salah, Mohamed',' Froward',122,'https://th.bing.com/th/id/OIP.7XprMnH1ANVi_ui97ZU5MgHaFj?w=224&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (717,'Jota, Diogo','Froward',122,'https://th.bing.com/th/id/OIP.EZjxVN4dP-nhGTqOqdxl7AHaE8?w=249&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (718,'Alcantara, Thiago','Midfield', 122,'https://th.bing.com/th/id/OIP.IDpTxmjiRaPM9Q198iOlOgHaE8?w=304&h=203&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (719,'Robertson, Andrew','Defender',122,'https://th.bing.com/th/id/OIP.Jwi4l17wGqEKOyD3Fu0s2AHaHa?w=184&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (720,'Oxlade-Chamberlain, Alex','Midfield ',122,'https://th.bing.com/th/id/OIP.kMxlwQ02A9DTMr1cEBn7BwHaFy?w=227&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (721,'Babacar,Khouma','Froward', 123,'https://th.bing.com/th/id/OIP.qi3kf3s_WEVBtghptj-d7QHaE8?w=243&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (722,'Lerager, Lukas','Midfield',123,'https://th.bing.com/th/id/OIP.mjPl8dFImGYEgHxDAC8jAwAAAA?w=198&h=198&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (723,'Ankersen, Peter','Defender',123,'https://th.bing.com/th/id/OIP.LmrNK3b1vH5P8aHaHQTHzQAAAA?w=167&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (724,'Khocholava, Davit','Defender', 123,'https://th.bing.com/th/id/OIP.X0pZvwMTwjQ_Hbe2FP0i8wAAAA?pid=ImgDet&rs=1')
		 insert into PlayersInfo values (725,'Grabara, Kamil','GoalKeeper',123,'https://th.bing.com/th/id/OIP.IMC_a5gjogvbsUwDylevAQAAAA?w=130&h=195&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (726,'Singh, Luther',' Froward',123,'https://th.bing.com/th/id/OIP.n-gsubcN1bDTD41oOcNSQwHaIo?w=146&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (727,'Karamoko, Mamoudou','Froward',123,'https://th.bing.com/th/id/OIP.UcWN3AUv6WcGzBD6Vs5t_AHaHP?w=167&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (728,'Falk, Rasmus','Midfield', 123,'https://th.bing.com/th/id/OIP.KboVh4A6ugXtR2R8FBByjwHaEK?w=285&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (729,'Oikonomou, Marios','Defender',123,'https://th.bing.com/th/id/OIP.6pQeMMiCI5nRQj_EvWMk3AHaFI?w=265&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (730,'Claesson, Viktor','Midfield ',123,'https://th.bing.com/th/id/OIP.K8Bh2JtivJiXVDfcgfxiywHaE8?w=252&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (731,'Bellarabi, Karim','Froward', 124,'https://th.bing.com/th/id/OIP.6qfeSY57ZN6K9wzYSVqy9gHaHa?w=173&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (732,'Aranguiz, Charles','Midfield',124,'https://th.bing.com/th/id/OIP.MES27gCTmHkQoVh9rHcc2AHaEK?w=300&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (733,'Weiser, Mitchell','Defender',124,'https://th.bing.com/th/id/OIP.ojma1MWXPC5KA9G9TiObMAHaFj?w=241&h=181&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (734,'Tah, Jonathan','Defender', 124,'https://th.bing.com/th/id/OIP.vqxWQc6iN8o3a5uTCyZMkAHaHa?w=171&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (735,'Hradecky, Lukas','GoalKeeper',124,'https://th.bing.com/th/id/OIP.-Z7roXhbyER8d_SXuqmcZAHaEK?w=272&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (736,'Pohjanpalo, Joel',' Froward',124,'https://th.bing.com/th/id/OIP.lCEphgiGChM4lVtb7AkSAwHaHD?w=165&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (737,'Schick, Patrik','Froward',124,'https://th.bing.com/th/id/OIP.G1ltUWMOOUuEwhrO2_nHDgHaEK?w=284&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (738,'Demirbay, Kerem','Midfield', 124,'https://th.bing.com/th/id/OIP.IuEAGgiG2l4Uajii4ICBRQHaEK?w=309&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (739,'Sinkgraven, Daley','Defender',124,'https://th.bing.com/th/id/OIP.83TTyA9fNbxADXBSl0X4fAHaHa?w=164&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (740,'Andrich,Robert','Midfield ',124,'https://th.bing.com/th/id/OIP.8EK1r1od_7o62_AyhYzzygAAAA?w=162&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (741,'Quioto, Romell','Froward', 125,'https://th.bing.com/th/id/OIP.wGlL6udJbs3kEgwWbg9M7gHaEo?w=285&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (742,'Wanyama, Victor','Midfield',125,'https://th.bing.com/th/id/OIP.cJVKCTYDdBmoLUrdwJnkewHaFy?w=241&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (743,'Camacho, Rudy','Defender',125,'https://th.bing.com/th/id/OIP.2Y6wrpnmnSxMJzMqCokknAAAAA?w=129&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (744,'Johnsen, Bjorn','Defender', 125,'https://th.bing.com/th/id/OIP.oZs-xGYURo9MBZtr0QAkiAHaEK?w=299&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (745,'Breza,Sebastian','GoalKeeper',125,'https://th.bing.com/th/id/OIP.Ff0cDgpJJ4HfnQxZh_V1vgHaKl?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (746,'Toye, Mason',' Froward',125,'https://th.bing.com/th/id/OIP.x3VywXsdeOJBvNT8P-6QbQHaFY?w=235&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (747,'Kamara, Kei','Froward',125,'https://th.bing.com/th/id/OIP.sfDBRdTS2TrziGsfo0dQ0gHaEK?w=275&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (748,'Piette, Samuel','Midfield', 125,'https://th.bing.com/th/id/OIP.GKnJt3AVboVuuaF5MT023gHaEK?w=333&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (749,'Brault Guillard, Zachary','Defender',125,'https://th.bing.com/th/id/OIP.negfjTLIa4iO3RTLtkRYJAHaEK?w=323&h=181&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (750,'Lappalainen, Lassi','Midfield ',125,'https://th.bing.com/th/id/OIP.ELJZvDuLn91r7REStekh4wHaEK?w=316&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (751,'Sobiech, Artur','Froward', 126,'https://th.bing.com/th/id/OIP.gFhmmIgC56BontG3fmWH0wHaFU?w=252&h=180&c=7&r=0&o=5&pid=1.77')
		 insert into PlayersInfo values (752,'Murawski,Radoslaw','Midfield',126,'https://th.bing.com/th/id/OIP.hb2FjhXgeT29HSPFXiiyWwAAAA?w=125&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (753,'Douglas, Barry','Defender',126,'https://th.bing.com/th/id/OIP.wgDJwpFWkMKA38uOz6RzcAHaE8?w=228&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (754,'Salamon, Bartosz','Defender', 126,'https://th.bing.com/th/id/OIP.kM8INakbXLfLwbQfALri0QHaH0?w=157&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (755,'Rudko, Artur','GoalKeeper',126,'https://th.bing.com/th/id/OIP.em4Y72cLpypWrWAroq99eQHaK1?w=126&h=184&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (756,'Ishak, Mikael',' Froward',126,'https://th.bing.com/th/id/OIP.rfjVcCn9tLlEGupWymL-HAHaJ4?w=129&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (757,'BA Loua, Adriel','Froward',126,'https://th.bing.com/th/id/OIP.t95BzgggH5riIBJDzN3m9AAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (758,'Kvekveskiri, Nika','Midfield', 126,'https://th.bing.com/th/id/OIP.ymKc1DiQSd2SPRF3cfMahQAAAA?w=127&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (759,'Rebocho','Defender',126,'https://th.bing.com/th/id/OIP.YL8Cy65wdSlPB2qV27MDpAHaHa?w=155&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (760,'Sykora, Jan','Midfield ',126,'https://th.bing.com/th/id/OIP.l9pVh4nWMNJwo5VWAn27hwAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (761,'Ighalo, Odion stats','Froward', 127,'https://th.bing.com/th/id/OIP.WF2Wintw5pMD2B9jBnxaAwAAAA?w=165&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (762,'Pereira, Matheus ','Midfield',127,'https://th.bing.com/th/id/OIP.FIv3gEgDjn9L4J25P4MTWQHaHa?w=182&h=182&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (763,'Kurdi, Amiri','Defender',127,'https://th.bing.com/th/id/OIP.IEBIn4uQ-zpa-bobnTZeUQAAAA?w=120&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (764,'Jang, Hyun Soo','Defender', 127,'https://th.bing.com/th/id/OIP.2qH9mqPZuj4LQ1uZThTOCQAAAA?w=139&h=181&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (765,'Al Muaiouf, Abdullah','GoalKeeper',127,'https://th.bing.com/th/id/OIP._G72cPy_yDmRRMjD0PC99AHaE8?w=271&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (766,'AL-Shehri, Saleh',' Froward',127,'https://th.bing.com/th/id/OIP.8IYdApo5HfJ41rO-UNk5hAAAAA?w=126&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7')
		 insert into PlayersInfo values (767,'Vietto, Luciano','Froward',127,'https://th.bing.com/th/id/OIP.b9JPeqDlBfpXUZ4jUxk8WgAAAA?w=146&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7')
		 insert into PlayersInfo values (768,'Al Faraj, Salman','Midfield', 127,'https://th.bing.com/th/id/OIP.OCRfNmR9-AIdpC2vm4nRsAAAAA?w=117&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (769,'Al Shahrani, Yasir','Defender',127,'https://th.bing.com/th/id/OIP.4TXSYMH74iaPo4xIeBknoQAAAA?w=119&h=180&c=7&r=0&o=5&dpr=1.5&pid=1.7')
		 insert into PlayersInfo values (770,'Carrillo, Andre','Midfield ',127,'https://th.bing.com/th/id/OIP.IdGH_GepajBDcNuVgxlW5QHaHa?w=180&h=180&c=7&r=0&o=5&pid=1.7')


		 insert into PlayersInfo values (771,'Lacazette, Alexandre','Froward', 128,'https://i.pinimg.com/originals/ae/b8/36/aeb8362038d60446f6988bf053679dfd.jpg')
		 insert into PlayersInfo values (772,'Mendes, Thiago ','Midfield',128,'https://th.bing.com/th/id/OIP.KgkrTs2wrS8k7jpB3ssLDQHaIH?w=160&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (773,'Boateng, Jerome','Defender',128,'https://th.bing.com/th/id/OIP.IEBIn4uQ-zpa-bobnTZeUQAAAA?w=120&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (774,'Da Silva, Damien','Defender', 128,'https://th.bing.com/th/id/OIP.5JTEVyVRBCrlWZjfAZtQGgHaFR?w=225&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (775,'Lopes, Anthony','GoalKeeper',128,'https://th.bing.com/th/id/OIP._G72cPy_yDmRRMjD0PC99AHaE8?w=271&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (776,'Ekambi, Karl Toko',' Froward',128,'https://th.bing.com/th/id/OIP.reNvQq5ElQlUu8O6O1NHXQHaHa?w=162&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (777,'Dembele,Moussa','Froward',128,'https://th.bing.com/th/id/OIP._RfBL8oiqVCTs6XSyfxGVAHaFO?w=223&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (778,'Tolisso, Corentin','Midfield', 128,'https://th.bing.com/th/id/OIP.XYjsK4EoFjy2PqSbbPKiEgDWEs?w=124&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (779,'Kone, Youssouf','Defender',128,'https://th.bing.com/th/id/OIP.LRDwMo-Dr68lNDLjammn1gHaHa?w=160&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (780,'Reine-Adelaide, Jeff','Midfield ',128,'https://th.bing.com/th/id/OIP._Z8EcgKMQDbxN71Jzd6zogHaFj?w=243&h=182&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (781,'lzquierdo, Jose','Froward', 129,'https://th.bing.com/th/id/OIP.x5HpJ73lMCYO9aNarq9BugAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (782,'Vormer, Ruud ','Midfield',129,'https://th.bing.com/th/id/OIP.49cCIjYzoZNvrsZBCpwSIgHaHa?w=157&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (783,'Odoi, Denis','Defender',129,'https://th.bing.com/th/id/OIP.q8T0iddRo2EYpUXmZzLBQgHaHa?w=152&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (784,'N`Soki,Stanley','Defender', 129,'https://th.bing.com/th/id/OIP.IgPixM-hZdXmH0y9F-w0TAAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (785,'Mignolet, Simon','GoalKeeper',129,'https://th.bing.com/th/id/OIP.9iAIWwbo5zgGVDXAmIee8wHaFj?w=222&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (786,'Buchanan, Tajon',' Froward',129,'https://th.bing.com/th/id/OIP.d13CTNQXS06_4MlB3pBc4QHaFY?w=204&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (787,'Vlietinck, Thibault','Froward',129,'https://th.bing.com/th/id/OIP.GWXuVectjTEvbwEw02CikgAAAA?w=149&h=186&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (788,'Rits, Mats','Midfield', 129,'https://th.bing.com/th/id/OIP.Lb0kv0JJ1k_gFdnr66LRVAHaFK?w=212&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (789,'Sobol, Eduard','Defender',129,'https://th.bing.com/th/id/OIP.iNv8ETd1UOkzkVLLq35nkwAAAA?w=114&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (790,'Vanaken, Hans','Midfield ',129,'https://th.bing.com/th/id/OIP.mfhlHuoOFfcVk1_tSX9zpAHaJm?w=123&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (791,'Perisic, Ivan','Froward', 130,'https://th.bing.com/th/id/OIP.8vRewtWnL4Zvy0JQyaQZ-AHaEK?w=302&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (792,'Dier, Eric ','Midfield',130,'https://th.bing.com/th/id/OIP.VtWGSQvXnb-D7JBbOhtKzQHaIS?w=174&h=195&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (793,'Davies, Ben','Defender',130,'https://th.bing.com/th/id/OIP.B5duFyBpYq6oibFcZerNBwHaIS?w=145&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (794,'Doherty, Matt','Defender', 130,'https://th.bing.com/th/id/OIP.BHQ1AgdTTecz_iJuXdXa8QAAAA?w=188&h=188&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (795,'Lloris, Hugo','GoalKeeper',130,'https://th.bing.com/th/id/OIP.BNdbEqoIqciABEjujeFTigHaHa?w=193&h=193&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (796,'Kane, Harry',' Froward',130,'https://th.bing.com/th/id/OIP.51ZIik6iKtg39XUhBLBX3QHaE8?w=281&h=187&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (797,'Son, Heung Min','Froward',130,'https://th.bing.com/th/id/OIP.dH1tyazu1ftMyd8kVBfD9AHaFy?w=198&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (798,'Hojbjerg, Pierre','Midfield', 130,'https://th.bing.com/th/id/OIP.7wXLo3h535j0egXS9f1EQgHaFj?w=252&h=189&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (799,'Sanchez,Davinson','Defender',130,'https://th.bing.com/th/id/OIP.7dbX3DC_8JmTIXmpULE-ggHaIS?w=149&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (800,'Moura, Lucas','Midfield ',130,'https://th.bing.com/th/id/OIP.uVh9sDgHeH9I_AlaHJL4egAAAA?w=131&h=180&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (801,'Afif, Ali Hassan','Froward', 131,'https://th.bing.com/th/id/OIP.E8DYj2Y1Ns5ab0FIdAZrAgAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values  (802,'Tae Hee, Nam ','Midfield',131,'https://th.bing.com/th/id/OIP.VNjJUPAPOCeJwr9cVsDbCgHaFF?w=279&h=192&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (803,'Alderweireld, Toby','Defender',131,'https://th.bing.com/th/id/OIP.RY_gqodutk2JSc83iXTK9QHaIS?w=181&h=203&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (804,'Musa, Mohammed','Defender', 131,'https://th.bing.com/th/id/OIP.lCM3szJBV68VC3aQjqrOjAAAAA?w=160&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (805,'Khalifa Ababacar','GoalKeeper',131,'https://th.bing.com/th/id/OIP.BNdbEqoIqciABEjujeFTigHaHa?w=193&h=193&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (806,'Msakni, Youssef',' Froward',131,'https://th.bing.com/th/id/OIP.SCiwUkn3_6mZYMWtr8DDsgHaEI?w=285&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (807,'Mohamad, Ismail','Froward',131,'https://th.bing.com/th/id/OIP.s-_m7IQp8-U2pkdsSUUdAQHaKQ?w=146&h=202&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (808,'Edmilson Junior','Midfield', 131,'https://th.bing.com/th/id/OIP.Mf1kBpKGGKdkI4tx5DA3cQHaGj?w=198&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (809,'Madibo, Assim','Defender',131,'https://th.bing.com/th/id/OIP.VetkSTmOlVjrU2jX-hRM0QGQGQ?w=186&h=186&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (810,'Boudiaf, Karim','Midfield ',131,'https://th.bing.com/th/id/OIP.vQffbd7y9rcAfFn_NBcxSgHaNO?w=115&h=186&c=7&r=0&o=5&pid=1.7')

		 insert into PlayersInfo values (811,'Amiri, Vahid','Froward', 132,'https://th.bing.com/th/id/OIP.e5tlZ22-qm6gdzkr3U7ESAAAAA?w=127&h=150&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values  (812,'Shiri, Mehdi','Midfield',132,'https://th.bing.com/th/id/OIP.ezMtuBd3AwmqdhPihoeJgwHaLK?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (813,'Hosseini, Jalal','Defender',132,'https://th.bing.com/th/id/OIP.K1gx7crNNx_eL_ZD9qk2tgAAAA?w=199&h=199&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (814,'Aghaei, Saeid','Defender', 132,'https://th.bing.com/th/id/OIP.ac8a2YyTskXOQKPQCOVVTQHaJQ?w=142&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (815,'Radosevic, Bozidar','GoalKeeper',132,'https://th.bing.com/th/id/OIP.GC6lZ_D5NUEkp_HQimF4OQAAAA?w=115&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (816,'Alkasir, Isa',' Froward',132,'https://th.bing.com/th/id/OIP.MerDxjnd00JZmSh2K2_lXwHaEK?w=276&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (817,'Abdi Qara, Mehdi','Froward',132,'https://th.bing.com/th/id/OIP.hop_lHJlgPy7jNUS14ibgwAAAA?w=186&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (818,'Sarlak, Milad','Midfield', 132,'https://th.bing.com/th/id/OIP.iKnjdHxK4VDIKDtPoVnbzAAAAA?w=138&h=180&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (819,'Shojaei, Ali','Defender',132,'https://th.bing.com/th/id/OIP.IwCkQw2sBg1u4Cb6oad0xwHaDu?w=315&h=176&c=7&r=0&o=5&pid=1.7')
		 insert into PlayersInfo values (820,'Pahlevan, Ehsan','Midfield ',132,'https://th.bing.com/th/id/OIP.UbLvuUaYi6MhODZ-z36AoQHaEK?w=308&h=180&c=7&r=0&o=5&pid=1.7')


		select *from PlayersInfo

	 delete from PlayersInfo where playerId=5