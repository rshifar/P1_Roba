﻿using System.Data.SqlClient;

namespace FIFAAPI
{
    public class Players
    {
          public  int playerId  {get;set;}
		  public string playerName { get; set; }                          
		  public string playerPosition { get; set; }
		   public  int  playerTeamId { get; set; }
		   public string playImageUrl { get; set; }

        SqlConnection con = new SqlConnection(@"server=DESKTOP-86SS27P\ROBAINSTANCE;database=FIFAAPIDB;user id=sa;password=password1234");

        public List<Players> GetAllPlayers()
        {
            SqlCommand cmd = new SqlCommand("select * from playersInfo", con);
            con.Open();
            List<Players> playersList = new List<Players>();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                playersList.Add(new Players()
                {
                    playerId = Convert.ToInt32(rd[0]),
                    playerName = rd[1].ToString(),
                    playerPosition = rd[2].ToString(),
                    playerTeamId = Convert.ToInt32(rd[3]),
                    playImageUrl = rd[4].ToString()
                });
            }
            rd.Close();
            con.Close();

            return playersList;
       }
        public Players GetPlayersById(int p_playeId)
        {
            SqlCommand cmd = new SqlCommand("select * from playersInfo where playerId=@playerId", con);
            cmd.Parameters.AddWithValue("@playerId", p_playeId);
            SqlDataReader rd = null;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    Players players = new Players()
                    {
                        playerId = Convert.ToInt32(rd[0]),
                        playerName = rd[1].ToString(),
                        playerPosition = rd[2].ToString(),
                        playerTeamId = Convert.ToInt32(rd[3]),
                        playImageUrl = rd[4].ToString()
                    };
                    return players;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Player Not Found");
                }
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }


        }

        public string AddPlayer(Players newPlayer)
        {
            SqlCommand cmd = new SqlCommand("insert into playersinfo values(@playerId,@playerName,@playerPosition,@playerTeamId,@playImageUrl)", con);
            cmd.Parameters.AddWithValue("@playerId", newPlayer.playerId);
            cmd.Parameters.AddWithValue("@playerName", newPlayer.playerName);
            cmd.Parameters.AddWithValue("@playerPosition", newPlayer.playerPosition);
            cmd.Parameters.AddWithValue("@playerTeamId", newPlayer.playerTeamId);
            cmd.Parameters.AddWithValue("@playImageUrl", newPlayer.playImageUrl);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "New Player Added  Successfully";
        }

        public string DeletePlayer(int playerId)
        {
            SqlCommand cmd = new SqlCommand("delete from playerIdsinfo where playerId=@playerId", con);
            cmd.Parameters.AddWithValue("@playerId", playerId);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            if (result == 1)
            {
                return "Player Deleted Successfully";
            }
            throw new Exception("Invalid Player  Number, Player number not found in system");

        }

        public string EditPlayer(Players changes)
        {
            SqlCommand cmd = new SqlCommand("update PlayersInfo set playerPosition=@playerPosition,playerName=@playerName where playerId =@playerId", con);
            cmd.Parameters.AddWithValue("@playerPosition", changes.playerPosition);
            cmd.Parameters.AddWithValue("@playerName", changes.playerName);
            cmd.Parameters.AddWithValue("@playerId", changes.playerId);

            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            return "Player Updated Successfully";
        }
    }
}
