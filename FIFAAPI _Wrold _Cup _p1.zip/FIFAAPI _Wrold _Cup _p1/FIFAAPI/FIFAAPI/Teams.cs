﻿
using System.Data.SqlClient;

namespace FIFAAPI
{
    public class Teams
    {
        public int teamId { get; set; }
        public string teamName { get; set; }
        public string teamCountry { get; set; }
        public string teamCoach { get; set; }
        public string teamCaptain { get; set; }
        public string teamLogo { get; set; }
        public string teamJersey { get; set; }
       

        SqlConnection con = new SqlConnection(@"server=DESKTOP-86SS27P\ROBAINSTANCE;database=FIFAAPIDB;user id=sa;password=password1234");

        public List<Teams> GetAllTeams()
        {
            SqlCommand cmd = new SqlCommand("select * from teamsInfo", con);
            con.Open();
            List<Teams> teamsList = new List<Teams>();
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                teamsList.Add(new Teams()
                {
                    teamId = Convert.ToInt32(rd[0]),
                    teamName = rd[1].ToString(),
                    teamCountry = rd[2].ToString(),
                    teamCoach = rd[3].ToString(),
                    teamCaptain = rd[4].ToString(),
                    teamLogo = rd[5].ToString(),
                    teamJersey = rd[6].ToString()
                   
                });
            }
            rd.Close();
            con.Close();

            return teamsList;

        }

        public Teams GetTeamsById(int p_teamId)
        {
            SqlCommand cmd = new SqlCommand("select * from teamsInfo where  teamId=@teamId", con);
            cmd.Parameters.AddWithValue("@teamId", p_teamId);
            SqlDataReader rd = null;
            try
            {
                con.Open();
                rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    Teams teams = new Teams()
                    {
                        teamId = Convert.ToInt32(rd[0]),
                        teamName = rd[1].ToString(),
                        teamCountry = rd[2].ToString(),
                        teamCoach = rd[3].ToString(),
                        teamCaptain = rd[4].ToString(),
                        teamLogo = rd[5].ToString(),
                        teamJersey = rd[6].ToString()
                    };
                    return teams;
                }
                else
                {
                    rd.Close();
                    con.Close();
                    throw new Exception("Team Not Found");
                }
            }
            catch (Exception es)
            {
                throw new Exception(es.Message);
            }
            finally
            {
                rd.Close();
                con.Close();
            }


        }


        public string AddTeam(Teams newTeam)
        {
            SqlCommand cmd = new SqlCommand("insert into teamsinfo values(@teamId,@teamName,@teamCountry,@teamCoach,@teamCaptain,@teamLogo,@teamJersey)", con);
            cmd.Parameters.AddWithValue("@teamId", newTeam.teamId);
            cmd.Parameters.AddWithValue("@teamName", newTeam.teamName);
            cmd.Parameters.AddWithValue("@teamCountry", newTeam.teamCountry);
            cmd.Parameters.AddWithValue("@teamCoach", newTeam.teamCoach);
            cmd.Parameters.AddWithValue("@teamCaptain", newTeam.teamCaptain);
            cmd.Parameters.AddWithValue("@teamLogo", newTeam.teamLogo);
            cmd.Parameters.AddWithValue("@teamJersey", newTeam.teamJersey);

            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            return "Team Created Successfully";
        }

        public string DeleteTeam(int teamId)
        {
            SqlCommand cmd = new SqlCommand("delete from teamsInfo where teamId=@teamId", con);
            cmd.Parameters.AddWithValue("@teamId", teamId);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            if (result == 1)
            {
                return "Team Deleted Successfully";
            }
            throw new Exception("Invalid Team  Number, Team number not found in system");

        }

        public string EditTeam(Teams changes)
        {
            SqlCommand cmd = new SqlCommand("update teamsinfo set teamLogo=@teamLogo,teamName=@teamName,teamCountry=@teamCountry,teamCoach=@teamCoach,teamCaptain=@teamCaptain,teamJersey=@teamJersey where teamId =@teamId", con);
            cmd.Parameters.AddWithValue("@teamLogo", changes.teamLogo);
            cmd.Parameters.AddWithValue("@teamName", changes.teamName);
            cmd.Parameters.AddWithValue("@teamId", changes.teamId);
            cmd.Parameters.AddWithValue("@teamCountry", changes.teamCountry);
            cmd.Parameters.AddWithValue("@teamCoach", changes.teamCoach);
            cmd.Parameters.AddWithValue("@teamCaptain", changes.teamCaptain);
            cmd.Parameters.AddWithValue("@teamJersey", changes.teamJersey);

            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();

            return "Team Updated Successfully";
        }
    }
}
