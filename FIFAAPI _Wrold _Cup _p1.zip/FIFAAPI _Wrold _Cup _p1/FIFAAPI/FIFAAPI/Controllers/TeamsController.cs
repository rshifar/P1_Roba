﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FIFAAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamsController : ControllerBase
    {
        Teams teamObj = new Teams();

        [HttpGet]
        [Route("teamlist")]
        public IActionResult GetAllAccounts()
        {
            return Ok(teamObj.GetAllTeams());
        }

        [HttpGet]
        [Route("teamlist/{teamId}")]
        public IActionResult GetTeamsById(int teamId)
        {
            try
            {
                return Ok(teamObj.GetTeamsById(teamId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        [Route("teamlist/add")]
        public IActionResult AddTeam(Teams newObj)
        {
            return Ok(teamObj.AddTeam(newObj));
        }

        [HttpDelete]
        [Route("teamlist/delete/{teamId}")]
        public IActionResult DeleteTeam(int teamId)
        {
            try
            {
                return Ok(teamObj.DeleteTeam(teamId));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }


        }
        [HttpPut]
        [Route("teamslist/edit")]
        public IActionResult UpdateAccount(Teams change)
        {
            return Ok(teamObj.EditTeam(change));
        }




    }
}
