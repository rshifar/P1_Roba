﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FIFAAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayersController : ControllerBase
    {
        Players playerObj = new Players();

        [HttpGet]
        [Route("playerlist")]
        public IActionResult GetAllPlayers()
        {
            return Ok(playerObj.GetAllPlayers());
        }

        [HttpGet]
        [Route("playerlist/{playerId}")]
        public IActionResult GetPlayersById(int playerId)
        {
            try
            {
                return Ok(playerObj.GetPlayersById(playerId));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        [Route("playerlist/add")]
        public IActionResult AddPlayer(Players newObj)
        {
            return Ok(playerObj.AddPlayer(newObj));
        }

        [HttpDelete]
        [Route("playerlist/delete/{playerId}")]
        public IActionResult DeletePlayer(int playerId)
        {
            try
            {
                return Ok(playerObj.DeletePlayer(playerId));
            }
            catch (Exception es)
            {
                return BadRequest(es.Message);
            }


        }
        [HttpPut]
        [Route("playerslist/edit")]
        public IActionResult UpdatePlayer(Players change)
        {
            return Ok(playerObj.EditPlayer(change));
        }




    }
}

